﻿// На вход принимает число, выдает четное/нечетное

Console.WriteLine("Введите положительное число");
int numb = Convert.ToInt32(Console.ReadLine());
if (numb % 2 == 0)
{
    Console.Write($"{numb} - является четным");
}
else
{
    Console.WriteLine($"{numb} - является нечетным");
}
