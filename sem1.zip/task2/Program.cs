﻿// На вход 3 числа, выдает максимальное

Console.WriteLine("Введите три числа");
int firstN = Convert.ToInt32(Console.ReadLine());
int secondN = Convert.ToInt32(Console.ReadLine());
int thirdN = Convert.ToInt32(Console.ReadLine());
int max = firstN;
if (secondN > max)
{
    max = secondN;
}
if (thirdN > max)
{
    max = thirdN;
}
Console.WriteLine($"{max} - максимальное число");