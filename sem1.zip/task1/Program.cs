﻿// На вход принимает два числа, выдает наибольшее и наименьшее

Console.WriteLine("Введите первое число");
int firstN = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Введите второе число");
int secondN = Convert.ToInt32(Console.ReadLine());
if (firstN > secondN)
{
    Console.Write($"{firstN} = является наибольшим числом, {secondN} = является наименьшим числом");
}
else
{
    Console.WriteLine($"{secondN} = является наибольшим числом, {firstN} = является наименьшим числом");
}