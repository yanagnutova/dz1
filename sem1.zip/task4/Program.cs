﻿// На вход принимает число N, на выходе показывает все четные от 1 до N

Console.WriteLine("Введите положительное число");
int numb = Convert.ToInt32(Console.ReadLine());
int schet = 0;
if (numb <= 1)
{
    Console.Write("Ошибка! Нет четных чисел");
}
while (schet <= numb)
{
    if (schet % 2 == 0 && schet > 0)
    {
        Console.WriteLine($"{schet}");
    }
    schet++;
    }
    

